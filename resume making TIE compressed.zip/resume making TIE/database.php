<?php
$username='root';
$password='';
$dbname = 'resume';
$dbname=new mysqli ('localhost',$username,$password,$dbname) or die("unable to connect");
?>
